from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from langchain_community.llms import Ollama
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
import pandas as pd
import os
import random

app = Flask(__name__)
app.secret_key = "prissila_secret"
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ======== INICIALIZACIÓN DEL MODELO ========
llm = Ollama(model="llama3")
chat_history = []

prompt_template = ChatPromptTemplate.from_messages([
    (
        "system",
        """Eres un AI llamado Prissila, especialista en Historia Universal.
        Solo puedes hablar sobre historia universal, medicina, ciencias, gente que influyo mucho en la historia universal y temas relacionados.
        Si te preguntan algo fuera de eso, responde que solo hablas de los temas mencionados.
        Debes mantener el contexto de la conversación.
        Las respuestas no serán tan largas, serán medianas"""
    ),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{input}"),
])

chain = prompt_template | llm

# ======== RUTAS PRINCIPALES ========
@app.route("/")
def index():
    return render_template("index.html")

# ======== CHAT ========
@app.route("/chat", methods=["POST"])
def chat():
    global chat_history
    data = request.json
    pregunta = data.get("input")
    if not pregunta:
        return jsonify({"error": "No input provided"}), 400

    # Verifica si hay preguntas guiadas
    if os.path.exists(os.path.join(UPLOAD_FOLDER, "preguntas.csv")):
        df = pd.read_csv(os.path.join(UPLOAD_FOLDER, "preguntas.csv"))
        if not df.empty and "activar preguntas" in pregunta.lower():
            pregunta_random = df.sample(1).iloc[0]
            texto = f"📜 Pregunta guiada de {pregunta_random['categoria']}: {pregunta_random['pregunta']}"
            return jsonify({"response": texto})

    response = chain.invoke({"input": pregunta, "chat_history": chat_history})
    chat_history.append(HumanMessage(content=pregunta))
    chat_history.append(AIMessage(content=response))
    return jsonify({"response": str(response)})


# ======== SUBIR TEMAS HISTÓRICOS (CSV) ========
@app.route("/upload")
def upload_page():
    return render_template("upload.html")

@app.route("/upload_csv", methods=["POST"])
def upload_csv():
    file = request.files.get("file")
    if not file or not file.filename.endswith(".csv"):
        flash("❌ Debes subir un archivo CSV válido.")
        return redirect(url_for("upload_page"))

    filepath = os.path.join(UPLOAD_FOLDER, "temas.csv")
    file.save(filepath)
    df = pd.read_csv(filepath)
    flash(f"✅ Archivo cargado correctamente ({len(df)} registros detectados).")
    return redirect(url_for("upload_page"))


# ======== MÓDULO DE PREGUNTAS GUIADAS ========
@app.route("/preguntas")
def preguntas_page():
    preguntas_path = os.path.join(UPLOAD_FOLDER, "preguntas.csv")
    if os.path.exists(preguntas_path):
        df = pd.read_csv(preguntas_path)
        preguntas = df.to_dict(orient="records")
    else:
        preguntas = []
    return render_template("preguntas.html", preguntas=preguntas)

@app.route("/guardar_pregunta", methods=["POST"])
def guardar_pregunta():
    titulo = request.form["titulo_sesion"]
    pregunta = request.form["pregunta"]
    categoria = request.form["categoria"]
    dificultad = request.form["dificultad"]

    preguntas_path = os.path.join(UPLOAD_FOLDER, "preguntas.csv")
    nueva_pregunta = pd.DataFrame([{
        "titulo_sesion": titulo,
        "pregunta": pregunta,
        "categoria": categoria,
        "dificultad": dificultad
    }])

    if os.path.exists(preguntas_path):
        df = pd.read_csv(preguntas_path)
        df = pd.concat([df, nueva_pregunta], ignore_index=True)
    else:
        df = nueva_pregunta

    df.to_csv(preguntas_path, index=False)
    flash("✅ Pregunta agregada correctamente.")
    return redirect(url_for("preguntas_page"))


# ======== MÓDULO DE LÍNEA DE TIEMPO ========
@app.route("/timeline")
def timeline_page():
    temas_path = os.path.join(UPLOAD_FOLDER, "temas.csv")
    eventos = []

    if os.path.exists(temas_path):
        df = pd.read_csv(temas_path)
        for _, row in df.iterrows():
            eventos.append({
                "fecha": str(row.get("fecha", "")),
                "evento": row.get("evento", ""),
                "descripcion": row.get("descripcion", "")
            })
    return render_template("timeline.html", eventos=eventos)


# ======== ELIMINAR LÍNEA DE TIEMPO ========
@app.route("/delete_timeline", methods=["POST"])
def delete_timeline():
    temas_path = os.path.join(UPLOAD_FOLDER, "temas.csv")

    if os.path.exists(temas_path):
        os.remove(temas_path)
        flash("🗑️ Línea de tiempo eliminada correctamente.")
    else:
        flash("⚠️ No existe una línea de tiempo para eliminar.")

    return redirect(url_for("timeline_page"))

if __name__ == "__main__":
    app.run(debug=True, port=5050)
