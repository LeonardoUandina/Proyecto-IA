async function sendMessage() {
  const inputField = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");

  const userMessage = inputField.value;
  if (!userMessage) return;

  // Mostrar mensaje del usuario
  chatBox.innerHTML += `<div class="message user">${userMessage}</div>`;
  inputField.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;

  // Enviar al backend Flask
  const response = await fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ input: userMessage })
  });

  const data = await response.json();
  const botMessage = data.response;

  // Mostrar respuesta del bot
  chatBox.innerHTML += `<div class="message bot">${botMessage}</div>`;
  chatBox.scrollTop = chatBox.scrollHeight;
}